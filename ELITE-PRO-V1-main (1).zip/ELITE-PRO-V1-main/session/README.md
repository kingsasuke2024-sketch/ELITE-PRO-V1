## HOW TO UPLOAD SESSION: 

---
- Click here to get session-id (creds.json). **[SESSION-ID](https://session-id-website.vercel.app)**
- Upload session-id on session folder. (session)
- Make sure your session is like this **creds.json** after uploading on your repo if not rename it.

---
**Visit our website for more.  [ELITEPROTECH](https://eliteprotech.zone.id)**
